# qantas tech test

Install
```
npm install
```

Run locally
```
npm app.js
```

Test an endpoint with JSON payload
```
GET http://localhost:8081/flights
```
